﻿
Import-Module $PSScriptRoot\Invoke-EnumerateAzureBlobs.ps1
Import-Module $PSScriptRoot\Invoke-EnumerateAzureSubDomains.ps1

Write-Host "Imported Misc MicroBurst functions"